﻿CREATE TABLE [dbo].[tbCategory]
(
	[catid] INT NOT NULL PRIMARY KEY IDENTITY, 
    [catname] VARCHAR(50) NOT NULL
)
